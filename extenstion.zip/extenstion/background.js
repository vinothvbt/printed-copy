// Create context menu items when the extension is installed
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "copySelected",
      title: "copy selected text",
      contexts: ["selection", "page"] // Display when text is selected or anywhere on the page
    });
  
    chrome.contextMenus.create({
      id: "copyAll",
      title: "Copy All Page Text",
      contexts: ["page"]
    });
  });
  
  // The function to be injected into the webpage
  function copyText(mode) {
    // Helper: show a notification that fades out after 1 second
    function showAutoDisappearingAlert(message) {
      let alertBox = document.createElement("div");
      alertBox.innerText = message;
      alertBox.style.position = "fixed";
      alertBox.style.top = "20px";
      alertBox.style.left = "50%";
      alertBox.style.transform = "translateX(-50%)";
      alertBox.style.background = "#333";
      alertBox.style.color = "#fff";
      alertBox.style.padding = "10px 20px";
      alertBox.style.borderRadius = "5px";
      alertBox.style.boxShadow = "0px 4px 6px rgba(0,0,0,0.1)";
      alertBox.style.zIndex = "10000";
      alertBox.style.fontSize = "14px";
      alertBox.style.transition = "opacity 0.5s ease";
      document.body.appendChild(alertBox);
      setTimeout(() => {
        alertBox.style.opacity = "0";
        setTimeout(() => alertBox.remove(), 500);
      }, 1000);
    }
  
    // Determine the text to copy based on the mode
    let text = "";
    if (mode === "selected") {
      text = window.getSelection().toString().trim();
      if (!text) {
        showAutoDisappearingAlert("⚠️ No text selected. Please highlight something.");
        return;
      }
    } else if (mode === "all") {
      text = document.body.innerText.trim();
      if (!text) {
        showAutoDisappearingAlert("⚠️ No text available to copy.");
        return;
      }
    } else {
      showAutoDisappearingAlert("❌ Invalid copy mode.");
      return;
    }
  
    // Try copying using the Clipboard API
    navigator.clipboard.writeText(text)
      .then(() => {
        showAutoDisappearingAlert("📋 Text copied successfully!");
      })
      .catch((error) => {
        // Fallback: use a temporary textarea for older support
        let textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.top = "-9999px";
        textArea.style.left = "-9999px";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
          if (document.execCommand("copy")) {
            showAutoDisappearingAlert("📋 Text copied successfully! (Fallback)");
          } else {
            showAutoDisappearingAlert("❌ Fallback: Unable to copy text.");
          }
        } catch (err) {
          showAutoDisappearingAlert("❌ Fallback: Unable to copy text. " + err);
        }
        document.body.removeChild(textArea);
      });
  }
  
  // Listen for context menu clicks
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (tab && tab.id) {
      let mode = "";
      if (info.menuItemId === "copySelected") {
        mode = "selected";
      } else if (info.menuItemId === "copyAll") {
        mode = "all";
      }
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: copyText,
        args: [mode]
      });
    }
  });
  