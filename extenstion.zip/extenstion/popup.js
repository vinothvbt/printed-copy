// Copy only the selected text
// Define the copyText function that will run in the page context.
function copyText(mode) {
    // Helper: Show an auto-disappearing alert.
    function showAutoDisappearingAlert(message) {
      let alertBox = document.createElement("div");
      alertBox.innerText = message;
      alertBox.style.position = "fixed";
      alertBox.style.top = "20px";
      alertBox.style.left = "50%";
      alertBox.style.transform = "translateX(-50%)";
      alertBox.style.background = "#333";
      alertBox.style.color = "#fff";
      alertBox.style.padding = "10px 20px";
      alertBox.style.borderRadius = "5px";
      alertBox.style.boxShadow = "0px 4px 6px rgba(0,0,0,0.1)";
      alertBox.style.zIndex = "10000";
      alertBox.style.fontSize = "14px";
      alertBox.style.transition = "opacity 0.5s ease";
      document.body.appendChild(alertBox);
      setTimeout(() => {
        alertBox.style.opacity = "0";
        setTimeout(() => alertBox.remove(), 500);
      }, 1000);
    }
  
    // Determine which text to copy.
    let text = "";
    if (mode === "selected") {
      text = window.getSelection().toString().trim();
      if (!text) {
        showAutoDisappearingAlert("⚠️ No text selected. Please highlight something.");
        return;
      }
    } else if (mode === "all") {
      text = document.body.innerText.trim();
      if (!text) {
        showAutoDisappearingAlert("⚠️ No text available to copy.");
        return;
      }
    } else {
      showAutoDisappearingAlert("❌ Invalid copy mode.");
      return;
    }
  
    // Try to use the Clipboard API.
    navigator.clipboard.writeText(text)
      .then(() => {
        showAutoDisappearingAlert("📋 Text copied successfully!");
      })
      .catch((error) => {
        // Fallback method: use a temporary textarea.
        let textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.top = "-9999px";
        textArea.style.left = "-9999px";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
          if (document.execCommand("copy")) {
            showAutoDisappearingAlert("📋 Text copied successfully! (Fallback)");
          } else {
            showAutoDisappearingAlert("❌ Fallback: Unable to copy text.");
          }
        } catch (err) {
          showAutoDisappearingAlert("❌ Fallback: Unable to copy text. " + err);
        }
        document.body.removeChild(textArea);
      });
  }
  
document.getElementById("copySelected").addEventListener("click", async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: copyText,
        args: ["selected"]
      });
    } else {
      alert("Error: Could not find active tab.");
    }
  });
  
  // Copy the whole page text
  document.getElementById("copyAll").addEventListener("click", async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: copyText,
        args: ["all"]
      });
    } else {
      alert("Error: Could not find active tab.");
    }
  });
  
  /* 
    The function 'copyText' is defined in content.js.  
    When injecting via chrome.scripting.executeScript, you can pass a function 
    from the current scope. However, if you prefer to keep your code in a separate file,
    simply use the 'files' property in executeScript and have both functions in content.js.
  */
    setInterval(() => {
      chrome.runtime.sendMessage("keepAlive", (response) => {
          if (chrome.runtime.lastError) {
              console.warn("Service worker might be inactive.");
          } else {
              console.log("Service worker is alive!", response);
          }
      });
  }, 10000);
  